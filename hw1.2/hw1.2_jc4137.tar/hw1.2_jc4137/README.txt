Run with
make
./hw1.1 [testscene.txt]

or
make ts#
# corresponds with testscene#.txt 
in total there are 5